import React from 'react'

function App() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-center text-blue-500">Welcome to MiseAI</h1>
    </div>
  )
}

export default App
