def get_sales():
    return []

def get_recipes():
    return []

def get_invoice_items():
    return []
